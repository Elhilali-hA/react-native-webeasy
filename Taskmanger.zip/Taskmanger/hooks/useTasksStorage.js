// hooks/useTasksStorage.js
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { setTasks } from '../redux/tasksSlice';

const TASKS_KEY = 'tasks';

const useTasksStorage = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    const loadTasks = async () => {
      try {
        const jsonValue = await AsyncStorage.getItem(TASKS_KEY);
        if (jsonValue != null) {
          const tasks = JSON.parse(jsonValue);
          dispatch(setTasks(tasks));
        }
      } catch (e) {
        console.error('Failed to load tasks', e);
      }
    };

    loadTasks();
  }, [dispatch]);

  const saveTasks = async (tasks) => {
    try {
      const jsonValue = JSON.stringify(tasks);
      await AsyncStorage.setItem(TASKS_KEY, jsonValue);
    } catch (e) {
      console.error('Failed to save tasks', e);
    }
  };

  return { saveTasks };
};

export default useTasksStorage;
