import { createSlice } from '@reduxjs/toolkit';

const tasksSlice = createSlice({
  name: 'tasks',
  initialState: {
    tasks: [],
  },
  reducers: {
    addTask(state, action) {
      state.tasks.push(action.payload);
    },
    markTaskCompleted(state, action) {
      const task = state.tasks.find(task => task.id === action.payload);
      if (task) task.completed = true;
    },
    removeTask(state, action) {
      state.tasks = state.tasks.filter(task => task.id !== action.payload);
    },
    updateTask(state, action) {
      const { id, title, description } = action.payload;
      const task = state.tasks.find(task => task.id === id);

      if (task) {
        task.title = title;
        task.description = description;
        task.completed = false;
      }
    },
    setTasks(state, action) {
      state.tasks = action.payload;
    }
  }
});

export const { addTask, markTaskCompleted, removeTask, updateTask, setTasks } = tasksSlice.actions;
export default tasksSlice.reducer;
