import React, { useEffect } from 'react';
import { Provider, useDispatch, useSelector } from 'react-redux';
import { SafeAreaView, StyleSheet, View, Text } from 'react-native';
import { store } from './redux/store';
import TaskInputForm from './components/TaskInputForm';
import TaskList from './components/TaskList';
import useTasksStorage from './hooks/useTasksStorage';
// import { NativeBaseProvider, Text, Box } from "native-base";
import { addTask, markTaskCompleted, removeTask, updateTask } from './redux/tasksSlice';

const AppContent = () => {
  const dispatch = useDispatch();
  const tasks = useSelector(state => state.tasks.tasks);
  const { saveTasks } = useTasksStorage();

  const handleAddTask = (task) => {
    const newTask = {
      id: Date.now().toString(),
      ...task,
      completed: false
    };
    dispatch(addTask(newTask));
  };

  const handleEditTask = (id, title, description) => {
    dispatch(updateTask({ id, title, description }));
  };

  useEffect(() => {
    saveTasks(tasks);
  }, [tasks, saveTasks]);

  return (
    <SafeAreaView style={styles.container}> 
    <View style={styles.header}>
      <Text style={styles.headTitle}>Add Tasks</Text>
    </View>
      <TaskInputForm onAddTask={handleAddTask} />
      <TaskList
      tasks={tasks}
      onMarkComplete={(id) => dispatch(markTaskCompleted(id))}
      onRemove={(id) => dispatch(removeTask(id))}
      onEdit={handleEditTask}
      />
    </SafeAreaView>
  );
};

export default function App() {
  return (
    <Provider store={store}>
      <AppContent />
    </Provider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    marginBottom: 20
  },
  header: {
    display: 'flex',
    justifyContent: 'center',
    padding: 20,
    marginTop: 15
  },
  headTitle : {
    fontSize: 20,
    fontWeight: '700',
    textAlign: 'center'
  }
});
