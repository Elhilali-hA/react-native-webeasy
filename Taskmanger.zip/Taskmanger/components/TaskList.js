import React, { useState } from 'react';
import { FlatList, StyleSheet, View, Text, TouchableOpacity } from 'react-native';
import TaskItem from './TaskItem';

const TaskList = ({ tasks, onMarkComplete, onRemove, onEdit, show }) => {
  const [showw, setShoww] = useState(show);

  const renderItem = ({ item }) => (
    <TaskItem
      task={item}
      onMarkComplete={onMarkComplete}
      onRemove={onRemove}
      onEdit={onEdit}
      show={showw}
    />
  );

  return (
    <View style={styles.taskList}>
      <View style={styles.todo}>
        <TouchableOpacity
          style={[styles.todoBtn, showw ? styles.backWhite : styles.background]}
          onPress={() => setShoww(false)}
        >
          <Text>TO DO</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.todoBtn, !showw ? styles.backWhite : styles.background]}
          onPress={() => setShoww(true)}
        >
          <Text>Done</Text>
        </TouchableOpacity>
      </View>
      <FlatList
        data={tasks}
        renderItem={renderItem}
        keyExtractor={item => item.id}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  taskList: {
    marginTop: 20,
  },
  todo: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    width: '100%',
    padding: 10,
    borderBottomWidth: 2,
    borderColor: 'blue',
    marginBottom: 15,
  },
  donBtn: {
    padding: 10,
  },
  background: {
    backgroundColor: '#AFE1AF',
  },
  backWhite: {
    backgroundColor: 'white',
  },
  todoBtn: {
    padding: 10,
  },
});

export default TaskList;
