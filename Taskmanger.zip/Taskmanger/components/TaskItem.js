import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, Alert } from 'react-native';

const TaskItem = ({ task, onMarkComplete, onRemove, onEdit, show }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedTitle, setEditedTitle] = useState(task.title);
  const [editedDescription, setEditedDescription] = useState(task.description);
  

  const handleEdit = () => {
    if (!editedTitle.trim()) {
      Alert.alert('Error', 'Title cannot be empty');
      return;
    }
    onEdit(task.id, editedTitle, editedDescription);
    setIsEditing(false);
  };

  return (
    <View style={styles.taskItem}>
      {isEditing ? (
        <>
          <TextInput
            value={editedTitle}
            onChangeText={setEditedTitle}
            style={styles.input}
          />
          <TextInput
            value={editedDescription}
            onChangeText={setEditedDescription}
            style={styles.input}
          />
          <View style={styles.btnsEdit}>
            <TouchableOpacity style={styles.saveBtn} onPress={handleEdit}>
              <Text style={styles.save}>Save</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.cancelBtn} onPress={() => setIsEditing(false)}>
              <Text>Cancel</Text>
            </TouchableOpacity>
          </View>
        </>
      ) : (
        <>
          {show && task.completed && (
            <View>
              <View style={[styles.headcomplete, task.completed && styles.completed]}>
                <View style={styles.headNote}>
                  <Text style={[styles.taskTitle, task.completed && styles.completed]}>
                    {task.title}
                  </Text>
                  {task.completed && <Text style={styles.done}>Done !</Text>}
                </View>
                <Text>{task.description}</Text>
              </View>
              <View style={styles.btns}>
                <TouchableOpacity
                  style={styles.btnComplete}
                  onPress={() => onMarkComplete(task.id)}
                  disabled={task.completed}
                >
                  <Text style={styles.colorWhite}>Mark as Completed</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.btnEdit}
                  onPress={() => setIsEditing(true)}
                >
                  <Text>Edit</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.btnremove}
                  onPress={() => onRemove(task.id)}
                >
                  <Text style={styles.colorWhite}>Remove</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
          {!show && !task.completed && (
            <View>
              <View style={styles.headcomplete}>
                <View style={styles.headNote}>
                  <Text style={[styles.taskTitle, task.completed && styles.completed]}>
                    {task.title}
                  </Text>
                  {task.completed && <Text style={styles.done}>Done !</Text>}
                </View>
                <Text>{task.description}</Text>
              </View>
              <View style={styles.btns}>
                <TouchableOpacity
                  style={styles.btnComplete}
                  onPress={() => onMarkComplete(task.id)}
                  disabled={task.completed}
                >
                  <Text style={styles.colorWhite}>Mark as Completed</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.btnEdit}
                  onPress={() => setIsEditing(true)}
                >
                  <Text>Edit</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.btnremove}
                  onPress={() => onRemove(task.id)}
                >
                  <Text style={styles.colorWhite}>Remove</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
        </>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  taskItem: {
    marginBottom: 15,
    marginTop: 15,
  },
  taskTitle: {
    fontWeight: 'bold',
    fontSize: 20,
  },
  headNote: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '100%',
  },
  done: {
    fontWeight: '700',
  },
  completed: {
    textDecorationLine: 'line-through',
    fontSize: 18,
    backgroundColor: '#AFE1AF',
  },
  input: {
    borderBottomWidth: 1,
    borderColor: '#ccc',
    marginBottom: 10,
    padding: 5,
  },
  btnsEdit: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'flex-end',
    padding: 20,
    borderRadius: 12,
  },
  headcomplete: {
    padding: 20,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'blue',
    borderRadius: 10,
    borderStyle: 'solid',
  },
  btns: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'flex-end',
    padding: 20,
    borderRadius: 12,
  },
  btnEdit: {
    padding: 10,
    borderRadius: 12,
  },
  btnComplete: {
    backgroundColor: 'green',
    padding: 10,
  },
  btnremove: {
    backgroundColor: 'red',
    padding: 10,
    borderRadius: 12,
  },
  colorWhite: {
    color: 'white',
  },
  cancelBtn: {
    padding: 10,
  },
  saveBtn: {
    padding: 10,
    backgroundColor: 'green',
  },
  save: {
    color: 'white',
  },
});

export default TaskItem;
